import ViewLayoutThree from "../News/ViewLayout/ViewLayoutThree";

const LayoutContentThree = () => {
  return <ViewLayoutThree />;
};
export default LayoutContentThree;
