export enum Layout {
  Layout_Default = "layoutdefault",
  Layout_Two = "layouttwo",
  Layout_Three = "layoutthree",
}
