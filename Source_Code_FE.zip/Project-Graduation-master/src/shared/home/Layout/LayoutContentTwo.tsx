import ViewLayoutTwo from "../News/ViewLayout/ViewLayoutTwo";

const LayoutContentTwo = () => {
  return <ViewLayoutTwo />;
};
export default LayoutContentTwo;
