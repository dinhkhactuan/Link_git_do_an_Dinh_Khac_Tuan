import ViewLayoutDefault from "../News/ViewLayout/ViewLayoutDefault";

const LayoutContentDefault = () => {
  return <ViewLayoutDefault />;
};
export default LayoutContentDefault;
