export enum FormCardItem {
  NO_DATE = "No_Date",
  ROW_REVERSE = "Row-Reverse",
  COL_REVERSE = "Col-Reverse",
}
