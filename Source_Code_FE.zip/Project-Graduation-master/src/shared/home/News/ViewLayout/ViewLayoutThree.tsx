
const ViewLayoutThree = () => {
  return (
    <>
      <div className="flex gap-2 mt-2">
        {/* <div className="w-1/4	">
          <LeftNews />
        </div>
        <div className="flex-1">
          <CenterNews />
        </div>
        <div className="w-1/4	">
          <RightNews />
          <Banner />
        </div> */}
      </div>
    </>
  );
};
export default ViewLayoutThree;
