import { Preview } from "../Preview";
import { Tab } from "../tab";

export const PreviewTheme = () => {
  return <Preview tab={Tab.THEME} />;
};
