export const enum Tab {
  THEME = "theme",
  PREVIEW_HOME = "previewHome",
}
