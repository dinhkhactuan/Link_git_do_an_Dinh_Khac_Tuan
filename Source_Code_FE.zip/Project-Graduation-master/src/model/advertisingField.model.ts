export interface INewAdvertisingField {
  advertisingFieldName: string;
}
export interface IAdvertisingField extends INewAdvertisingField {
  advertisingFieldId: number;
}
