import LoginForm from "@/shared/components/Auth/LoginForm";

export default async function Page() {
  return <LoginForm />;
}
