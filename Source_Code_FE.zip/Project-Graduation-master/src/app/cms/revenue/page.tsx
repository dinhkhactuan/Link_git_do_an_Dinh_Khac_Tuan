import RevenueManagement from "./RevenueManagement";

const Role = () => {
  return (
    <>
      <RevenueManagement />
    </>
  );
};

export default Role;
