import Content from "./Content";

const ProfileManagement = () => {
  return (
    <>
      <Content />
    </>
  );
};

export default ProfileManagement;
