import ApprovalManagement from "./ApprovalManagement";

const Approval = () => {
  return (
    <>
      <ApprovalManagement />
    </>
  );
};

export default Approval;
