import React from "react";

const SettingManagement = () => {
  return <></>;
};

export default SettingManagement;
