import SearchPage from "./SearchPage";

const PageNews = async () => {
  return (
    <>
      <SearchPage />
    </>
  );
};
export default PageNews;
