package com.Graduation_Be;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TuanGaApplicationTests {

    @Test
    void contextLoads() {
    }

}
