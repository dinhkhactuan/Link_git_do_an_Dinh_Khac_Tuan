package com.Graduation_Be.shard.enums;

public enum AdvertisementStatus {
    PENDING, APPROVED, REJECTED
}
