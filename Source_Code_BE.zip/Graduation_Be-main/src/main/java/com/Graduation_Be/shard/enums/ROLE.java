package com.Graduation_Be.shard.enums;

public enum ROLE {
    ADMIN,
    ADVERTISEMENT
}
