package com.Graduation_Be.shard.enums;

public enum MessageSys {
    USER_NOT_EXIST,
    ID_NOT_EXIST,
    NOT_FOUND,
    ERROR_SERVER,
    SUSSCESS
}
