package com.Graduation_Be.shard.enums;

public enum ApprovalStatus {
    PENDING, APPROVED, REJECTED
}
