package com.Graduation_Be.dto.resquest.AdvertisingField;

import lombok.Data;

@Data
public class AdvertisingFieldRequestDTO {
    private String advertisingFieldName;
}